﻿using Unrez.Essential;

namespace Unrez.BackyardShowdown
{
    public class PetsContainer : Singleton<PetsContainer>
    {
        public PetProfile[] Pets;

    }
}