namespace Unrez.BackyardShowdown
{
    public enum PetType
    {
        Cat,
        Dog
    }
}