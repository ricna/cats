﻿
namespace Unrez.BackyardShowdown
{
    public interface IInteractable
    {
        void Interact(Pet pet);
        void Release();
    }
}