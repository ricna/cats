﻿namespace Unrez
{
    public class ScareTree
    {
    }
}