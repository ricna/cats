using UnityEngine;

public class SpawnPoints : MonoBehaviour
{
    public Transform[] Spawns;
}
