
namespace Unrez.Networking
{
    public static class NetworkingScenes
    {
        public const string SCENE_BOOTSTRAP_NAME = "01_NetBootstrap";
        public const string SCENE_MAIN_MENU = "02_MainMenu";
        public const string SCENE_MATCH_NAME = "03_Match";
        public const string SCENE_LOBBY = "04_Lobby";
    }
}