﻿using Unrez.Essential;

namespace Unrez.Networking
{

    public class NetHandlerDedicatedServer : Singleton<NetHandlerDedicatedServer>
    {
        
        private void Start()
        {
           
        }
    }
}